<div class="card mt-5">
    <div class="card-header fs-4" style="font-weight: 600;">Atenção</div> 
    <div class="card-body">
            <div class="row">
            <form method="post" action="<?php echo base_url('index.php/Motorista/confirmar_exclusao/'. $viagem); ?>">
                <p class="form-label mb-3 fs-4">Deseja realmente excluir o item?</p>
                <!-- Input oculto para enviar a confirmação -->
                <!-- Botão de envio -->
                <button name="botao" class="btn btn-primary px-3 py-1 fs-4" value="nao" type="submit">Não</button>
                <input type="hidden" class="form-control" name="confirmacao" value="confirmacao">
                <!-- Botão de envio -->
                <button name="botao" class="btn btn-danger ms-3 px-3 py-1 fs-4" value="sim" type="submit">Excluir</button>

            </form>
        </div>
    </div>
</div>