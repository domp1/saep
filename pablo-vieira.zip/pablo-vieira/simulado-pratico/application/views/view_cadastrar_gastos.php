<div class="card mt-5">
    <div class="card-header fs-4" style="font-weight: 600;">Cadastro de Gastos</div> 
    <div class="card-body">
        <div class="row">
            <form action="<?php echo base_url('index.php/Motorista/cadastra_gasto/'. $viagem); ?>" method="post">
                <div class="mb-3">
                    <label for="text" class="form-label">Descrição</label>
                    <input type="text" class="form-control" id="descricao" name="descricao">
                </div>
                <button type="submit" class="btn btn-primary px-3 py-2 fs-4">Cadastrar</button>
            </form>
        </div>
    </div>
</div>