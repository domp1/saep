<div class="row mt-5">
        <h1>Listagem de Viagens</h1>

        <table class="table table-striped">
            <thead>
                <tr>
                    <th scope="col">Nome</th>
                    <th colspan="2" scope="col" >Visualização e Cadastro de Gastos</th>
                    <th scope="col">Excluir</th>
                </tr>
            </thead>
            <tbody>
                
                <?php foreach($viagens as $viagem): ?>
                <tr>
                    <td><?php echo $viagem->nome?></td>
                    <td>
                        <a class="btn btn-primary" href="<?php echo base_url('index.php/Motorista/gastos/'.$viagem->idviagens)?>">
                            <i class="fa fa-pencil" aria-hidden="true"></i> Ver Gastos
                        </a>
                    </td>
                    <td>
                        <a class="btn btn-primary" href="<?php echo base_url('index.php/Motorista/cadastrar_gastos/'.$viagem->idviagens)?>">
                            <i class="fa fa-pencil" aria-hidden="true"></i> Cadastrar Gastos
                        </a>
                    </td>
                    <td>
                        <a class="btn btn-danger" href="<?php echo base_url('index.php/Motorista/excluir/'.$viagem->idviagens)?>">
                            <i class="fa fa-trash" aria-hidden="true"></i> Excluir Viagem
                        </a>
                    </td>       
                </tr>
                <?php endforeach?>
            </tbody>
        </table>
        <div class="row d-inline ">
            <a class="btn btn-secondary mt-2 py-2 fs-4" style="width: 400px;" href="<?php echo base_url('index.php/Motorista/cadastrar_viagem/'.$viagens[0]->motoristas_idmotoristas)?>">
                <i class="fa fa-trash" aria-hidden="true"></i> Cadastrar Viagem
            </a>
        </div>
    </div>