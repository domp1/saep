Esse simulado foi feito para nossa preparação para a prova prática do SAEP ( prova organizada para medir o nível dos alunos de cada curso do SENAI ). Esse simulado basicamente é desenvolver um sistema que atenda à causa de determinada empresa, e para isso é necessário alguns passos como: 
	A criação do diagrama de caso de uso; 
	A criação do modelo do banco de dados; 
	Script de criação e população do banco de dados; 
	Tela de autenticação de usuários (login); 
	Tela principal do motorista; 
	Listar viagens do motorista; 
	Exclusão de viagens; 
	Tela de gastos da viagem; 
	Listar gastos por viagem; 
	Sair do sistema (logout); 
	E por fim a lista de requisitos de infraestrutura;

Utilizei para o desenvolvimento desse sistema o USBWebServer ( para visualização do sistema e do banco de dados ), o vscode para criação dos scripts, e como framework o CodeIgniter, combinado com o Bootstrap. Reconheço que minha solução possui muito a ser feito e melhorado. Entretanto decidi tornar público esse repositório pois acredito que ele contenha amostras de um grande avanço em meu curso.
The CodeIgniter team would like to thank EllisLab, all the
contributors to the CodeIgniter project and you, the CodeIgniter user.
